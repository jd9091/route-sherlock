#!/usr/bin/env python3
"""
Example usage of Route Sherlock RIPEstat client.

This script demonstrates basic usage of the RIPEstat API client.

Usage:
    python examples/basic_usage.py
    
    # Or with a specific ASN:
    python examples/basic_usage.py AS13335
"""

import asyncio
import sys
from datetime import datetime, timedelta

# Add src to path for development
sys.path.insert(0, "src")

from route_sherlock.collectors.ripestat import RIPEstatClient
from route_sherlock.cache.store import MemoryCache


async def investigate_asn(asn: str) -> None:
    """
    Gather comprehensive information about an ASN.
    
    This is a simplified version of what the full incident investigation
    tool will do.
    """
    print(f"\n{'='*60}")
    print(f"  Route Sherlock: Investigating {asn}")
    print(f"{'='*60}\n")
    
    # Use memory cache for this example
    cache = MemoryCache()
    
    async with RIPEstatClient(cache=cache) as client:
        # 1. Basic AS Overview
        print("📋 AS Overview")
        print("-" * 40)
        try:
            overview = await client.get_as_overview(asn)
            print(f"  ASN:      {asn}")
            print(f"  Holder:   {overview.holder}")
            print(f"  Active:   {'Yes' if overview.announced else 'No'}")
        except Exception as e:
            print(f"  Error: {e}")
        print()
        
        # 2. Current Routing Status
        print("🌐 Routing Status")
        print("-" * 40)
        try:
            status = await client.get_routing_status(asn)
            print(f"  Observed neighbours: {status.observed_neighbours}")
            if status.neighbour_counts:
                print(f"  Upstreams:   {status.neighbour_counts.get('left', 'N/A')}")
                print(f"  Downstreams: {status.neighbour_counts.get('right', 'N/A')}")
        except Exception as e:
            print(f"  Error: {e}")
        print()
        
        # 3. Announced Prefixes
        print("📡 Announced Prefixes")
        print("-" * 40)
        try:
            prefixes = await client.get_announced_prefixes(asn)
            print(f"  Total:  {prefixes.prefix_count}")
            print(f"  IPv4:   {len(prefixes.ipv4_prefixes)}")
            print(f"  IPv6:   {len(prefixes.ipv6_prefixes)}")
            
            if prefixes.prefixes:
                print(f"\n  Sample prefixes (first 5):")
                for p in prefixes.prefixes[:5]:
                    print(f"    • {p.prefix}")
        except Exception as e:
            print(f"  Error: {e}")
        print()
        
        # 4. AS Neighbours (Upstreams/Downstreams)
        print("🔗 Neighbours")
        print("-" * 40)
        try:
            neighbours = await client.get_as_neighbours(asn)
            
            upstreams = neighbours.upstreams[:5]
            if upstreams:
                print(f"  Top Upstreams:")
                for n in upstreams:
                    print(f"    • AS{n.asn} (power: {n.power})")
            
            downstreams = neighbours.downstreams[:5]
            if downstreams:
                print(f"\n  Top Downstreams:")
                for n in downstreams:
                    print(f"    • AS{n.asn} (power: {n.power})")
        except Exception as e:
            print(f"  Error: {e}")
        print()
        
        # 5. Quick RPKI Check (just first few prefixes)
        print("🔐 RPKI Status (sample)")
        print("-" * 40)
        try:
            prefixes = await client.get_announced_prefixes(asn)
            sample_prefixes = prefixes.prefixes[:3]
            
            for p in sample_prefixes:
                try:
                    rpki = await client.get_rpki_validation(p.prefix, asn)
                    status_icon = "✅" if rpki.status == "valid" else "❌" if rpki.status == "invalid" else "❓"
                    print(f"  {status_icon} {p.prefix}: {rpki.status}")
                except Exception:
                    print(f"  ⚠️  {p.prefix}: Could not validate")
                await asyncio.sleep(0.2)  # Rate limiting
        except Exception as e:
            print(f"  Error: {e}")
        print()
    
    print(f"{'='*60}")
    print("  Investigation complete")
    print(f"{'='*60}\n")


async def compare_path_lengths(asn1: str, asn2: str) -> None:
    """
    Compare AS path lengths between two ASNs.
    
    Useful for peering evaluation.
    """
    print(f"\n📊 Path Length Comparison: {asn1} vs {asn2}\n")
    
    async with RIPEstatClient() as client:
        path1 = await client.get_as_path_length(asn1)
        path2 = await client.get_as_path_length(asn2)
        
        print(f"  {asn1}: {path1.stats}")
        print(f"  {asn2}: {path2.stats}")


async def main():
    """Main entry point."""
    # Default ASN to investigate
    asn = sys.argv[1] if len(sys.argv) > 1 else "AS13335"  # Cloudflare
    
    await investigate_asn(asn)


if __name__ == "__main__":
    asyncio.run(main())
