"""Tests for route-sherlock."""
