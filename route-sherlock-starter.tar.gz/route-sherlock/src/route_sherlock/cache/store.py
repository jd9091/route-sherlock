"""
Cache implementation for API responses.

Uses diskcache for persistent caching with TTL support.
Falls back to in-memory cache if diskcache unavailable.
"""

import json
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

try:
    import diskcache
    DISKCACHE_AVAILABLE = True
except ImportError:
    DISKCACHE_AVAILABLE = False


class Cache(ABC):
    """Abstract base class for cache implementations."""
    
    @abstractmethod
    async def get(self, key: str) -> Any | None:
        """Get value from cache."""
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Set value in cache with optional TTL."""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete value from cache."""
        pass
    
    @abstractmethod
    async def clear(self) -> None:
        """Clear all cached values."""
        pass


class MemoryCache(Cache):
    """
    Simple in-memory cache with TTL support.
    
    Note: Data is lost when process exits. Use DiskCache for persistence.
    """
    
    def __init__(self):
        self._store: dict[str, tuple[Any, float | None]] = {}
    
    async def get(self, key: str) -> Any | None:
        if key not in self._store:
            return None
        
        value, expires_at = self._store[key]
        
        if expires_at is not None and time.time() > expires_at:
            del self._store[key]
            return None
        
        return value
    
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        expires_at = time.time() + ttl if ttl else None
        self._store[key] = (value, expires_at)
    
    async def delete(self, key: str) -> None:
        self._store.pop(key, None)
    
    async def clear(self) -> None:
        self._store.clear()
    
    def __len__(self) -> int:
        return len(self._store)


class DiskCache(Cache):
    """
    Persistent disk-based cache using diskcache library.
    
    Survives process restarts. Recommended for production use.
    
    Example:
        cache = DiskCache("~/.cache/route-sherlock")
        await cache.set("key", {"data": "value"}, ttl=3600)
        data = await cache.get("key")
    """
    
    def __init__(self, directory: str | Path | None = None, size_limit: int = 2**30):
        """
        Initialize disk cache.
        
        Args:
            directory: Cache directory path (default: ~/.cache/route-sherlock)
            size_limit: Maximum cache size in bytes (default: 1GB)
        """
        if not DISKCACHE_AVAILABLE:
            raise ImportError("diskcache is required for DiskCache. Install with: pip install diskcache")
        
        if directory is None:
            directory = Path.home() / ".cache" / "route-sherlock"
        
        self._directory = Path(directory)
        self._directory.mkdir(parents=True, exist_ok=True)
        self._cache = diskcache.Cache(str(self._directory), size_limit=size_limit)
    
    async def get(self, key: str) -> Any | None:
        """Get value from disk cache."""
        value = self._cache.get(key)
        if value is None:
            return None
        
        # Deserialize JSON if stored as string
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return value
        return value
    
    async def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        """Set value in disk cache."""
        # Serialize complex objects to JSON
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        
        self._cache.set(key, value, expire=ttl)
    
    async def delete(self, key: str) -> None:
        """Delete value from disk cache."""
        self._cache.delete(key)
    
    async def clear(self) -> None:
        """Clear all cached values."""
        self._cache.clear()
    
    def close(self) -> None:
        """Close the cache connection."""
        self._cache.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    @property
    def stats(self) -> dict[str, Any]:
        """Get cache statistics."""
        return {
            "size": len(self._cache),
            "volume": self._cache.volume(),
            "directory": str(self._directory),
        }


def get_cache(cache_type: str = "disk", **kwargs) -> Cache:
    """
    Factory function to get appropriate cache instance.
    
    Args:
        cache_type: 'disk' or 'memory'
        **kwargs: Additional arguments for cache constructor
        
    Returns:
        Cache instance
    """
    if cache_type == "disk":
        if not DISKCACHE_AVAILABLE:
            print("Warning: diskcache not available, falling back to memory cache")
            return MemoryCache()
        return DiskCache(**kwargs)
    elif cache_type == "memory":
        return MemoryCache()
    else:
        raise ValueError(f"Unknown cache type: {cache_type}")
