# Route Sherlock 🔍

**Historical BGP intelligence for network operators**

Route Sherlock is an open-source tool that synthesizes public BGP data into actionable intelligence. It answers two questions network operators frequently ask:

1. **"What happened?"** — Incident investigation with timeline and evidence
2. **"Should I peer?"** — Data-driven peering decision support

## Features

- 🔎 **Incident Investigation**: Correlate BGP changes with latency impact
- 🤝 **Peering Evaluation**: Analyze potential peering opportunities
- 📊 **Historical Analysis**: Query days/weeks of routing history
- 🤖 **AI Synthesis**: Plain-English explanations (via Claude API)
- 💾 **Caching**: Minimize API calls with intelligent caching
- 🆓 **100% Public Data**: Works without any credentials

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/route-sherlock.git
cd route-sherlock

# Install with Poetry
poetry install

# Or with pip
pip install -e .
```

## Quick Start

```bash
# Investigate an ASN
route-sherlock investigate AS16509 --time "2025-01-01 14:00" --duration 2h

# Evaluate a peering opportunity
route-sherlock peering-eval --my-asn AS64500 --target AS13335
```

## Usage Examples

### Python API

```python
import asyncio
from route_sherlock.collectors import RIPEstatClient

async def main():
    async with RIPEstatClient() as client:
        # Get AS overview
        overview = await client.get_as_overview("AS13335")
        print(f"AS13335 ({overview.holder})")
        
        # Get announced prefixes
        prefixes = await client.get_announced_prefixes("AS13335")
        print(f"Announces {prefixes.prefix_count} prefixes")
        
        # Get neighbours
        neighbours = await client.get_as_neighbours("AS13335")
        print(f"Has {len(neighbours.upstreams)} upstreams")

asyncio.run(main())
```

### With Caching

```python
from route_sherlock.collectors import RIPEstatClient
from route_sherlock.cache import DiskCache

cache = DiskCache("~/.cache/route-sherlock")

async with RIPEstatClient(cache=cache) as client:
    # First call hits API
    status = await client.get_routing_status("AS13335")
    
    # Second call uses cache
    status = await client.get_routing_status("AS13335")
```

## Data Sources

| Source | Data | Cost |
|--------|------|------|
| [RIPEstat](https://stat.ripe.net/) | BGP routes, history, RPKI | Free |
| [RIPE Atlas](https://atlas.ripe.net/) | Latency measurements | Free (reads) |
| [PeeringDB](https://www.peeringdb.com/) | IX presence, policies | Free |
| [BGPStream](https://bgpstream.caida.org/) | Real-time updates | Free |

## Project Structure

```
route-sherlock/
├── src/route_sherlock/
│   ├── collectors/        # API clients
│   │   ├── ripestat.py    # RIPEstat API
│   │   ├── atlas.py       # RIPE Atlas API (TODO)
│   │   └── peeringdb.py   # PeeringDB API (TODO)
│   ├── models/            # Pydantic models
│   ├── analyzers/         # Analysis logic (TODO)
│   ├── synthesis/         # AI synthesis (TODO)
│   └── cli/               # CLI commands (TODO)
├── tests/
├── examples/
└── docs/
```

## Development

```bash
# Run tests
poetry run pytest tests/ -v

# Type checking
poetry run mypy src/

# Linting
poetry run ruff check src/

# Run example
poetry run python examples/basic_usage.py AS13335
```

## Roadmap

### Phase 1: Data Layer ✅
- [x] RIPEstat client
- [x] Response caching
- [ ] RIPE Atlas client
- [ ] PeeringDB client
- [ ] BGPStream integration

### Phase 2: Analysis
- [ ] Incident timeline builder
- [ ] Anomaly detection
- [ ] Peering opportunity finder
- [ ] Latency estimation

### Phase 3: Synthesis
- [ ] Claude API integration
- [ ] Incident report generation
- [ ] Peering recommendation engine

### Phase 4: CLI & Polish
- [ ] Full CLI with Typer
- [ ] Rich console output
- [ ] Export formats (JSON, Markdown)

## Contributing

Contributions welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) first.

## License

Apache 2.0 - see [LICENSE](LICENSE)

## Acknowledgments

- [RIPE NCC](https://www.ripe.net/) for RIPEstat and RIPE Atlas
- [PeeringDB](https://www.peeringdb.com/) for IX data
- [CAIDA](https://www.caida.org/) for BGPStream
