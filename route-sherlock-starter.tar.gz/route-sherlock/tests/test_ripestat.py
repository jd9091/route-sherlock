"""
Tests for RIPEstat client.

Run with: pytest tests/ -v
"""

import pytest
from datetime import datetime, timedelta
from unittest.mock import AsyncMock, patch

from route_sherlock.collectors.ripestat import RIPEstatClient, RIPEstatError
from route_sherlock.cache.store import MemoryCache


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def mock_as_overview_response():
    return {
        "status": "ok",
        "status_code": 200,
        "version": "1.0",
        "data_call_name": "as-overview",
        "data_call_status": "supported",
        "cached": False,
        "query_id": "test-123",
        "process_time": 100,
        "server_id": "test",
        "build_version": "1.0",
        "data": {
            "resource": "16509",
            "holder": "AMAZON-02",
            "announced": True,
            "block": {"name": "ARIN"}
        }
    }


@pytest.fixture
def mock_routing_status_response():
    return {
        "status": "ok",
        "status_code": 200,
        "version": "1.0",
        "data_call_name": "routing-status",
        "data_call_status": "supported",
        "cached": False,
        "query_id": "test-123",
        "process_time": 100,
        "server_id": "test",
        "build_version": "1.0",
        "data": {
            "resource": "AS16509",
            "query_time": "2025-01-01T00:00:00",
            "observed_neighbours": 150,
            "neighbour_counts": {"left": 50, "right": 100},
            "prefixes": [
                {"prefix": "52.94.0.0/15", "origin": 16509},
                {"prefix": "54.239.0.0/17", "origin": 16509},
            ]
        }
    }


@pytest.fixture
def mock_announced_prefixes_response():
    return {
        "status": "ok",
        "status_code": 200,
        "version": "1.0",
        "data_call_name": "announced-prefixes",
        "data_call_status": "supported",
        "cached": False,
        "query_id": "test-123",
        "process_time": 100,
        "server_id": "test",
        "build_version": "1.0",
        "data": {
            "resource": "AS16509",
            "query_time": "2025-01-01T00:00:00",
            "prefixes": [
                {
                    "prefix": "52.94.0.0/15",
                    "timelines": [
                        {"starttime": "2024-01-01T00:00:00", "endtime": "2025-01-01T00:00:00"}
                    ]
                },
                {
                    "prefix": "2600:1f00::/24",
                    "timelines": [
                        {"starttime": "2024-01-01T00:00:00", "endtime": "2025-01-01T00:00:00"}
                    ]
                },
            ]
        }
    }


# ============================================================================
# Tests
# ============================================================================

class TestRIPEstatClient:
    """Tests for RIPEstatClient."""
    
    @pytest.mark.asyncio
    async def test_normalize_resource_asn_with_prefix(self):
        """ASN with AS prefix should be normalized to uppercase."""
        assert RIPEstatClient._normalize_resource("as16509") == "AS16509"
    
    @pytest.mark.asyncio
    async def test_normalize_resource_asn_without_prefix(self):
        """ASN without AS prefix should have it added."""
        assert RIPEstatClient._normalize_resource("16509") == "AS16509"
    
    @pytest.mark.asyncio
    async def test_normalize_resource_prefix(self):
        """IP prefix should be returned as-is (uppercase)."""
        assert RIPEstatClient._normalize_resource("52.94.0.0/15") == "52.94.0.0/15"
    
    @pytest.mark.asyncio
    async def test_format_time(self):
        """Datetime should be formatted correctly."""
        dt = datetime(2025, 1, 1, 14, 30)
        assert RIPEstatClient._format_time(dt) == "2025-01-01T14:30"
    
    @pytest.mark.asyncio
    async def test_get_as_overview(self, mock_as_overview_response):
        """Should parse AS overview response correctly."""
        with patch("httpx.AsyncClient.get") as mock_get:
            mock_response = AsyncMock()
            mock_response.status_code = 200
            mock_response.json.return_value = mock_as_overview_response
            mock_response.raise_for_status = AsyncMock()
            mock_get.return_value = mock_response
            
            async with RIPEstatClient() as client:
                result = await client.get_as_overview("AS16509")
            
            assert result.holder == "AMAZON-02"
            assert result.announced is True
    
    @pytest.mark.asyncio
    async def test_get_routing_status(self, mock_routing_status_response):
        """Should parse routing status response correctly."""
        with patch("httpx.AsyncClient.get") as mock_get:
            mock_response = AsyncMock()
            mock_response.status_code = 200
            mock_response.json.return_value = mock_routing_status_response
            mock_response.raise_for_status = AsyncMock()
            mock_get.return_value = mock_response
            
            async with RIPEstatClient() as client:
                result = await client.get_routing_status("AS16509")
            
            assert result.observed_neighbours == 150
            assert len(result.prefixes) == 2
    
    @pytest.mark.asyncio
    async def test_get_announced_prefixes(self, mock_announced_prefixes_response):
        """Should parse announced prefixes and categorize IPv4/IPv6."""
        with patch("httpx.AsyncClient.get") as mock_get:
            mock_response = AsyncMock()
            mock_response.status_code = 200
            mock_response.json.return_value = mock_announced_prefixes_response
            mock_response.raise_for_status = AsyncMock()
            mock_get.return_value = mock_response
            
            async with RIPEstatClient() as client:
                result = await client.get_announced_prefixes("AS16509")
            
            assert result.prefix_count == 2
            assert len(result.ipv4_prefixes) == 1
            assert len(result.ipv6_prefixes) == 1
    
    @pytest.mark.asyncio
    async def test_caching(self, mock_routing_status_response):
        """Should cache responses and return from cache on second call."""
        cache = MemoryCache()
        
        with patch("httpx.AsyncClient.get") as mock_get:
            mock_response = AsyncMock()
            mock_response.status_code = 200
            mock_response.json.return_value = mock_routing_status_response
            mock_response.raise_for_status = AsyncMock()
            mock_get.return_value = mock_response
            
            async with RIPEstatClient(cache=cache) as client:
                # First call - should hit API
                result1 = await client.get_routing_status("AS16509")
                
                # Second call - should hit cache
                result2 = await client.get_routing_status("AS16509")
            
            # API should only be called once
            assert mock_get.call_count == 1
            assert result1.observed_neighbours == result2.observed_neighbours
    
    @pytest.mark.asyncio
    async def test_client_not_initialized_error(self):
        """Should raise error if client used without context manager."""
        client = RIPEstatClient()
        
        with pytest.raises(RIPEstatError, match="Client not initialized"):
            await client.get_as_overview("AS16509")


class TestMemoryCache:
    """Tests for MemoryCache."""
    
    @pytest.mark.asyncio
    async def test_set_and_get(self):
        """Should store and retrieve values."""
        cache = MemoryCache()
        await cache.set("key", {"data": "value"})
        result = await cache.get("key")
        assert result == {"data": "value"}
    
    @pytest.mark.asyncio
    async def test_get_nonexistent(self):
        """Should return None for nonexistent keys."""
        cache = MemoryCache()
        result = await cache.get("nonexistent")
        assert result is None
    
    @pytest.mark.asyncio
    async def test_ttl_expiration(self):
        """Should expire values after TTL."""
        cache = MemoryCache()
        await cache.set("key", "value", ttl=0)  # Immediate expiration
        
        # Simulate time passing
        import time
        time.sleep(0.1)
        
        result = await cache.get("key")
        assert result is None
    
    @pytest.mark.asyncio
    async def test_delete(self):
        """Should delete values."""
        cache = MemoryCache()
        await cache.set("key", "value")
        await cache.delete("key")
        result = await cache.get("key")
        assert result is None
    
    @pytest.mark.asyncio
    async def test_clear(self):
        """Should clear all values."""
        cache = MemoryCache()
        await cache.set("key1", "value1")
        await cache.set("key2", "value2")
        await cache.clear()
        assert len(cache) == 0
