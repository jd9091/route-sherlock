"""
Pydantic models for RIPEstat API responses.

These models provide type safety and validation for API responses.
"""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


# ============================================================================
# Base Models
# ============================================================================

class RIPEstatResponse(BaseModel):
    """Base response wrapper from RIPEstat API."""
    
    status: str
    status_code: int
    version: str
    data_call_name: str
    data_call_status: str
    cached: bool
    query_id: str
    process_time: int
    server_id: str
    build_version: str
    data: dict[str, Any]
    
    @property
    def is_success(self) -> bool:
        return self.status == "ok" and self.status_code == 200


# ============================================================================
# AS Overview Models
# ============================================================================

class ASOverview(BaseModel):
    """Overview information for an ASN."""
    
    asn: int = Field(alias="resource")
    holder: str | None = None
    announced: bool = True
    block: dict[str, Any] | None = None
    
    class Config:
        populate_by_name = True


# ============================================================================
# Routing Status Models
# ============================================================================

class RoutingStatusPrefix(BaseModel):
    """A prefix in routing status response."""
    
    prefix: str
    origin: int
    

class RoutingStatus(BaseModel):
    """Current routing status for an ASN or prefix."""
    
    resource: str
    query_time: datetime
    visibility: dict[str, Any] | None = None
    announced_space: dict[str, Any] | None = None
    observed_neighbours: int | None = None
    neighbour_counts: dict[str, int] | None = None
    prefixes: list[RoutingStatusPrefix] = Field(default_factory=list)


# ============================================================================
# Routing History Models
# ============================================================================

class RoutingHistoryTimeline(BaseModel):
    """A timeline entry showing when a prefix was announced."""
    
    starttime: datetime
    endtime: datetime


class RoutingHistoryPrefix(BaseModel):
    """A prefix with its announcement timeline."""
    
    prefix: str
    timelines: list[RoutingHistoryTimeline]


class RoutingHistoryOrigin(BaseModel):
    """Prefixes grouped by origin AS."""
    
    origin: str
    prefixes: list[RoutingHistoryPrefix]


class RoutingHistory(BaseModel):
    """Historical routing information for an ASN or prefix."""
    
    resource: str
    query_starttime: datetime
    query_endtime: datetime
    by_origin: list[RoutingHistoryOrigin] = Field(default_factory=list)


# ============================================================================
# BGP Updates Models
# ============================================================================

class BGPUpdate(BaseModel):
    """A single BGP update event."""
    
    timestamp: datetime
    type: str  # 'A' for announcement, 'W' for withdrawal
    attrs: dict[str, Any]
    source_id: str | None = None
    

class BGPUpdates(BaseModel):
    """BGP update activity for a resource."""
    
    resource: str
    query_starttime: datetime
    query_endtime: datetime
    nr_updates: int
    updates: list[BGPUpdate] = Field(default_factory=list)


# ============================================================================
# Announced Prefixes Models
# ============================================================================

class AnnouncedPrefix(BaseModel):
    """A prefix announced by an ASN."""
    
    prefix: str
    timelines: list[RoutingHistoryTimeline]


class AnnouncedPrefixes(BaseModel):
    """All prefixes announced by an ASN."""
    
    resource: str
    query_time: datetime
    prefixes: list[AnnouncedPrefix] = Field(default_factory=list)
    
    @property
    def prefix_count(self) -> int:
        return len(self.prefixes)
    
    @property
    def ipv4_prefixes(self) -> list[AnnouncedPrefix]:
        return [p for p in self.prefixes if ":" not in p.prefix]
    
    @property
    def ipv6_prefixes(self) -> list[AnnouncedPrefix]:
        return [p for p in self.prefixes if ":" in p.prefix]


# ============================================================================
# AS Path Length Models
# ============================================================================

class ASPathLengthDistribution(BaseModel):
    """Distribution of AS path lengths."""
    
    count: int
    path_length: int


class ASPathLength(BaseModel):
    """AS path length statistics for a resource."""
    
    resource: str
    query_time: datetime
    stats: dict[str, Any]
    distributions: list[ASPathLengthDistribution] = Field(default_factory=list)


# ============================================================================
# RPKI Validation Models
# ============================================================================

class RPKIValidationROA(BaseModel):
    """A Route Origin Authorization."""
    
    origin: str
    prefix: str
    max_length: int
    validity: str  # 'valid', 'invalid', 'unknown'


class RPKIValidation(BaseModel):
    """RPKI validation status for a prefix."""
    
    resource: str
    prefix: str
    query_time: datetime
    status: str  # 'valid', 'invalid', 'not-found'
    validating_roas: list[RPKIValidationROA] = Field(default_factory=list)


# ============================================================================
# AS Neighbours Models
# ============================================================================

class ASNeighbour(BaseModel):
    """A neighbouring AS."""
    
    asn: int
    type: str  # 'left' (upstream), 'right' (downstream)
    power: int  # Number of connections
    v4_peers: int = 0
    v6_peers: int = 0


class ASNeighbours(BaseModel):
    """Neighbouring ASes for an ASN."""
    
    resource: str
    query_time: datetime
    neighbour_counts: dict[str, int]
    neighbours: list[ASNeighbour] = Field(default_factory=list)
    
    @property
    def upstreams(self) -> list[ASNeighbour]:
        return [n for n in self.neighbours if n.type == "left"]
    
    @property
    def downstreams(self) -> list[ASNeighbour]:
        return [n for n in self.neighbours if n.type == "right"]


# ============================================================================
# Looking Glass Models
# ============================================================================

class LookingGlassPath(BaseModel):
    """A BGP path from a looking glass."""
    
    as_path: list[int]
    community: list[str] = Field(default_factory=list)
    next_hop: str | None = None
    origin: str | None = None
    peer: str | None = None
    

class LookingGlassResult(BaseModel):
    """Result from a looking glass query."""
    
    prefix: str
    paths: list[LookingGlassPath] = Field(default_factory=list)


class LookingGlass(BaseModel):
    """Looking glass query results."""
    
    resource: str
    query_time: datetime
    rrcs: dict[str, list[LookingGlassResult]]  # RRC ID -> results
